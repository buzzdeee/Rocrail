/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jun 10 2013 09:10:34)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: StrTok
  * Date: Mon Jun 10 14:39:46 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/strtok_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOStrTokData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OStrTok ----- */


/** Get number of tokens. */
static int _countTokens( struct OStrTok* inst ) {
  return 0;
}


/** There are more tokens left to read. */
static Boolean _hasMoreTokens( struct OStrTok* inst ) {
  return 0;
}


/** Object creator. */
static struct OStrTok* _inst( const char* str ,char sep ) {
  iOStrTok __StrTok = allocMem( sizeof( struct OStrTok ) );
  iOStrTokData data = allocMem( sizeof( struct OStrTokData ) );
  MemOp.basecpy( __StrTok, &StrTokOp, 0, sizeof( struct OStrTok ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __StrTok;
}


/** A token. */
static const char* _nextToken( struct OStrTok* inst ) {
  return 0;
}


/**  */
static char* _replaceAll( const char* str ,char sep ,const char* oldTok ,const char* newTok ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/strtok.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
