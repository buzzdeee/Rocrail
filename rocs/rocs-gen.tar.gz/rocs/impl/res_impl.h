/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Aug 22 2014 09:00:39)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Aug 23 16:21:31 2014
  */

#include "rocs/public/res.h"


static const char* name = "ORes";

typedef struct OResData {

    /** Message values mapped with their key. */
  iOMap msgMap;
    /**  */
  const char* xmlStr;
    /**  */
  const char* language;
    /**  */
  iONode msgNode;

} *iOResData;

static iOResData Data( void* p ) { return (iOResData)((iORes)p)->base.data; }

