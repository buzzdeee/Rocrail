/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr 10 2013 08:20:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: JS
  * Date: Thu Apr 11 06:52:07 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/js_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOJSData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OJS ----- */


/**  */
static int _init( struct OJS* inst ,int* devicemap ) {
  return 0;
}


/** Object creator. */
static struct OJS* _inst( void ) {
  iOJS __JS = allocMem( sizeof( struct OJS ) );
  iOJSData data = allocMem( sizeof( struct OJSData ) );
  MemOp.basecpy( __JS, &JSOp, 0, sizeof( struct OJS ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __JS;
}


/** Set an JS listener. */
static Boolean _setListener( struct OJS* inst ,jsListener listener ,int devnr ) {
  return 0;
}


/**  */
static void _start( struct OJS* inst ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/js.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
