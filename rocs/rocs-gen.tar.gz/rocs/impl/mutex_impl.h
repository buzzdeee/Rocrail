/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Aug 22 2014 09:00:39)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Aug 23 16:21:31 2014
  */

#include "rocs/public/mutex.h"


static const char* name = "OMutex";

typedef struct OMutexData {

    /** Mutex name. */
  char* name;
    /** Mutex handle. */
  void* handle;
    /**  */
  void* mh;
    /**  */
  int rc;

} *iOMutexData;

static iOMutexData Data( void* p ) { return (iOMutexData)((iOMutex)p)->base.data; }

