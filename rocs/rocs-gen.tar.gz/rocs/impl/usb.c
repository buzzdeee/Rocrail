/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jan 14 2014 20:57:44)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: USB
  * Date: Wed Jan 15 15:58:09 2014
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/usb_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOUSBData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OUSB ----- */


/**  */
static Boolean _close( struct OUSB* inst ) {
  return 0;
}


/** Object creator. */
static struct OUSB* _inst( void ) {
  iOUSB __USB = allocMem( sizeof( struct OUSB ) );
  iOUSBData data = allocMem( sizeof( struct OUSBData ) );
  MemOp.basecpy( __USB, &USBOp, 0, sizeof( struct OUSB ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __USB;
}


/**  */
static Boolean _open( struct OUSB* inst ,int vendor ,int product ,int configNr ,int interfaceNr ) {
  return 0;
}


/**  */
static Boolean _read( struct OUSB* inst ,unsigned char* buf ,int len ) {
  return 0;
}


/**  */
static Boolean _write( struct OUSB* inst ,unsigned char* buf ,int len ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/usb.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
