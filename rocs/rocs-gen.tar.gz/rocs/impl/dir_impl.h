/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Aug 22 2014 09:00:39)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Aug 23 16:21:31 2014
  */

#include "rocs/public/dir.h"


static const char* name = "ODir";

typedef struct ODirData {

    /** Path pointing to the directory. */
  char* path;
    /** Last error. */
  int rc;
    /** Directory structure as defined in dirent.h. */
  DIR* dir;

} *iODirData;

static iODirData Data( void* p ) { return (iODirData)((iODir)p)->base.data; }

