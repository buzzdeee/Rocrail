/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr 10 2013 08:20:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Queue
  * Date: Thu Apr 11 06:52:07 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/queue_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOQueueData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OQueue ----- */


/** Number of messages in the queue. */
static int _count( struct OQueue* inst ) {
  return 0;
}


/** Read a message. */
static obj _get( struct OQueue* inst ) {
  return 0;
}


/** Object creator. */
static struct OQueue* _inst( int size ) {
  iOQueue __Queue = allocMem( sizeof( struct OQueue ) );
  iOQueueData data = allocMem( sizeof( struct OQueueData ) );
  MemOp.basecpy( __Queue, &QueueOp, 0, sizeof( struct OQueue ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Queue;
}


/** Are messages in the queue? */
static Boolean _isEmpty( struct OQueue* inst ) {
  return 0;
}


/** Post a message. */
static Boolean _post( struct OQueue* inst ,obj object ,q_prio prio ) {
  return 0;
}


/** Set the Queues description. */
static void _setDesc( struct OQueue* inst ,const char* desc ) {
  return;
}


/** Wait for a messages. */
static obj _waitPost( struct OQueue* inst ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/queue.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
