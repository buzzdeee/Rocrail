/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr 10 2013 08:20:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Event
  * Date: Thu Apr 11 06:52:07 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/event_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOEventData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OEvent ----- */


/** Object creator. */
static struct OEvent* _inst( const char* name ,Boolean create ) {
  iOEvent __Event = allocMem( sizeof( struct OEvent ) );
  iOEventData data = allocMem( sizeof( struct OEventData ) );
  MemOp.basecpy( __Event, &EventOp, 0, sizeof( struct OEvent ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Event;
}


/** Reset the event. */
static Boolean _reset( struct OEvent* inst ) {
  return 0;
}


/** Set the event. */
static Boolean _set( struct OEvent* inst ) {
  return 0;
}


/** Wait a given time for event to become posted. */
static Boolean _trywait( struct OEvent* inst ,int time ) {
  return 0;
}


/** Wait for event to become posted. */
static Boolean _wait( struct OEvent* inst ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/event.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
