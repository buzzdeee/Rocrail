/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Aug 22 2014 09:00:39)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Aug 23 16:21:31 2014
  */

#ifndef __object_Mime64_H
#define __object_Mime64_H

#include "rocs/public/rocs.h"
#include "rocs/public/objbase.h"

#ifdef __cplusplus
  extern "C" {
#endif





typedef struct OMime64 {
  /***** Base *****/
  struct OBase  base;

  /***** Object: Mime64 *****/
  /** decode the input file into it's  */
  Boolean (*decode)( const char* infile ,const char* outfile );
  /** encode the input file into mime64 */
  Boolean (*encode)( const char* infile ,const char* outfile );
} *iOMime64;

extern struct OMime64 Mime64Op;

#ifdef __cplusplus
  }
#endif


#endif
